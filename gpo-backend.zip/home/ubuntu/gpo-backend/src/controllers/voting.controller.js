const Voting = require("../models/Voting");
const Group = require("../models/Group");

// @desc    Create new vote
// @route   POST /api/voting
// @access  Private (Group Admin/Creator)
exports.createVote = async (req, res, next) => {
  try {
    const { group, title, description, options, startDate, endDate, isAnonymous } = req.body;

    // Check if group exists
    const groupExists = await Group.findById(group);
    if (!groupExists) {
      return res.status(404).json({ success: false, message: "Group not found" });
    }

    // Check if user is authorized to create vote (creator or group admin)
    const isCreator = groupExists.creator.toString() === req.user.id;
    const isGroupAdmin = groupExists.members.some(
      (member) => member.user.toString() === req.user.id && member.role === "admin"
    );

    if (!isCreator && !isGroupAdmin) {
      return res.status(403).json({ success: false, message: "Not authorized to create vote in this group" });
    }

    // Validate options format
    if (!Array.isArray(options) || options.length < 2 || !options.every(opt => typeof opt.text === 'string')) {
        return res.status(400).json({ success: false, message: "Invalid options format. Provide at least two options with text." });
    }

    const formattedOptions = options.map(opt => ({ text: opt.text, votes: 0 }));

    const vote = await Voting.create({
      group,
      title,
      description,
      options: formattedOptions,
      createdBy: req.user.id,
      startDate,
      endDate,
      isAnonymous: isAnonymous !== undefined ? isAnonymous : true,
      status: "pending",
      participants: [],
    });

    // Optionally update group status or flag
    // await Group.findByIdAndUpdate(group, { votingActive: true });

    res.status(201).json({ success: true, data: vote });
  } catch (error) {
    next(error);
  }
};

// @desc    Get vote by ID
// @route   GET /api/voting/:id
// @access  Private (Group Member)
exports.getVoteById = async (req, res, next) => {
  try {
    const vote = await Voting.findById(req.params.id)
      .populate("group", "name members")
      .populate("createdBy", "username fullName");

    if (!vote) {
      return res.status(404).json({ success: false, message: "Vote not found" });
    }

    // Check if user is a member of the group
    const group = await Group.findById(vote.group._id);
    const isMember = group.members.some(member => member.user.toString() === req.user.id);
    const isAdmin = ["admin", "supervisor"].includes(req.user.role);

    if (!isMember && !isAdmin) {
        return res.status(403).json({ success: false, message: "Not authorized to access this vote" });
    }

    // Hide participant details if anonymous and vote not ended
    if (vote.isAnonymous && vote.status !== 'completed') {
        vote.participants = undefined; // Hide participants array
    }

    res.status(200).json({ success: true, data: vote });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all votes for a group
// @route   GET /api/groups/:id/voting
// @access  Private (Group Member)
exports.getGroupVotes = async (req, res, next) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) {
      return res.status(404).json({ success: false, message: "Group not found" });
    }

    // Check if user is a member of the group
    const isMember = group.members.some(member => member.user.toString() === req.user.id);
    const isAdmin = ["admin", "supervisor"].includes(req.user.role);

    if (!isMember && !isAdmin) {
        return res.status(403).json({ success: false, message: "Not authorized to access votes for this group" });
    }

    const votes = await Voting.find({ group: req.params.id })
        .populate("createdBy", "username fullName")
        .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: votes.length, data: votes });
  } catch (error) {
    next(error);
  }
};

// @desc    Submit vote
// @route   POST /api/voting/:id/vote
// @access  Private (Group Member)
exports.submitVote = async (req, res, next) => {
  try {
    const { optionIndex } = req.body;
    const voteId = req.params.id;
    const userId = req.user.id;

    const vote = await Voting.findById(voteId).populate('group', 'members');

    if (!vote) {
      return res.status(404).json({ success: false, message: "Vote not found" });
    }

    // Check if user is a member of the group
    const isMember = vote.group.members.some(member => member.user.toString() === userId);
    if (!isMember) {
        return res.status(403).json({ success: false, message: "Not authorized to vote in this poll" });
    }

    // Check if voting is active
    const now = new Date();
    if (vote.status !== "active" || now < vote.startDate || now > vote.endDate) {
      return res.status(400).json({ success: false, message: "Voting is not active or has ended" });
    }

    // Check if user has already voted
    const alreadyVoted = vote.participants.some(p => p.user.toString() === userId);
    if (alreadyVoted) {
      return res.status(400).json({ success: false, message: "You have already voted in this poll" });
    }

    // Validate option index
    if (optionIndex === undefined || optionIndex < 0 || optionIndex >= vote.options.length) {
      return res.status(400).json({ success: false, message: "Invalid option selected" });
    }

    // Record vote
    vote.options[optionIndex].votes += 1;
    vote.participants.push({ user: userId, votedOption: optionIndex, votedAt: Date.now() });

    await vote.save();

    res.status(200).json({ success: true, message: "Vote submitted successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Get vote results
// @route   GET /api/voting/:id/results
// @access  Private (Group Member, after end date)
exports.getVoteResults = async (req, res, next) => {
  try {
    const vote = await Voting.findById(req.params.id)
        .populate("group", "members")
        .populate("participants.user", "username fullName");

    if (!vote) {
      return res.status(404).json({ success: false, message: "Vote not found" });
    }

    // Check if user is a member of the group
    const isMember = vote.group.members.some(member => member.user.toString() === req.user.id);
    const isAdmin = ["admin", "supervisor"].includes(req.user.role);

    if (!isMember && !isAdmin) {
        return res.status(403).json({ success: false, message: "Not authorized to view results for this vote" });
    }

    // Check if voting has ended
    const now = new Date();
    if (vote.status !== 'completed' && now <= vote.endDate) {
        return res.status(400).json({ success: false, message: "Voting has not ended yet" });
    }

    // Optionally update status if not already completed
    if (vote.status !== 'completed') {
        vote.status = 'completed';
        await vote.save();
    }

    // Prepare results
    const results = {
        title: vote.title,
        description: vote.description,
        options: vote.options,
        totalVotes: vote.participants.length,
        participants: vote.isAnonymous ? undefined : vote.participants // Show participants if not anonymous
    };

    res.status(200).json({ success: true, data: results });
  } catch (error) {
    next(error);
  }
};

// @desc    Activate/Update vote status (e.g., start vote)
// @route   PUT /api/voting/:id/status
// @access  Private (Creator/Admin)
exports.updateVoteStatus = async (req, res, next) => {
    try {
        const { status } = req.body;
        const voteId = req.params.id;

        if (!status || !["pending", "active", "completed", "cancelled"].includes(status)) {
            return res.status(400).json({ success: false, message: "Invalid status provided" });
        }

        const vote = await Voting.findById(voteId).populate('group', 'creator members');

        if (!vote) {
            return res.status(404).json({ success: false, message: "Vote not found" });
        }

        // Check authorization (creator or group admin)
        const isCreator = vote.group.creator.toString() === req.user.id;
        const isGroupAdmin = vote.group.members.some(
            (member) => member.user.toString() === req.user.id && member.role === "admin"
        );
        const isSystemAdmin = ["admin", "supervisor"].includes(req.user.role);

        if (!isCreator && !isGroupAdmin && !isSystemAdmin) {
            return res.status(403).json({ success: false, message: "Not authorized to update vote status" });
        }

        // Update status
        vote.status = status;
        await vote.save();

        res.status(200).json({ success: true, data: vote });
    } catch (error) {
        next(error);
    }
};
