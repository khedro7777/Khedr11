const Group = require("../models/Group");
const User = require("../models/User");

// @desc    Search groups
// @route   GET /api/search/groups
// @access  Public
exports.searchGroups = async (req, res, next) => {
  try {
    const { query, sector, country, status, resourceType } = req.query;
    const filter = {};

    // Basic text search on name and description
    if (query) {
      filter.$text = { $search: query };
      // Ensure text index exists on Group model for name and description fields
      // Example: GroupSchema.index({ name: 'text', description: 'text' });
    }

    if (sector) filter.sector = sector;
    if (country) filter.country = country;
    if (status) filter.status = status;
    if (resourceType) filter.resourceType = resourceType;

    // Only show approved/active to public unless admin
    if (!req.user || !["admin", "supervisor"].includes(req.user.role)) {
      filter.status = { $in: ["approved", "active"] };
    }

    const groups = await Group.find(filter)
      .populate("creator", "username fullName")
      .limit(50); // Limit search results

    res.status(200).json({ success: true, count: groups.length, data: groups });
  } catch (error) {
    // Handle potential text index missing error
    if (error.message.includes("text index required")) {
        console.error("Text index missing on Group collection for text search.");
        return res.status(500).json({ success: false, message: "Search functionality requires text index setup on the database." });
    }
    next(error);
  }
};

// @desc    Search users
// @route   GET /api/search/users
// @access  Private/Admin
exports.searchUsers = async (req, res, next) => {
  try {
    const { query, role, country, sector } = req.query;
    const filter = {};

    // Basic text search on username, email, fullName
    if (query) {
      filter.$text = { $search: query };
      // Ensure text index exists on User model
      // Example: UserSchema.index({ username: 'text', email: 'text', fullName: 'text' });
    }

    if (role) filter.role = role;
    if (country) filter.country = country;
    if (sector) filter.sector = sector;

    const users = await User.find(filter)
        .select("-password")
        .limit(50);

    res.status(200).json({ success: true, count: users.length, data: users });
  } catch (error) {
     // Handle potential text index missing error
    if (error.message.includes("text index required")) {
        console.error("Text index missing on User collection for text search.");
        return res.status(500).json({ success: false, message: "Search functionality requires text index setup on the database." });
    }
    next(error);
  }
};

// @desc    Get list of sectors (Lookup)
// @route   GET /api/lookup/sectors
// @access  Public
exports.getSectors = async (req, res, next) => {
    try {
        // In a real app, this might come from a dedicated collection or config
        // For now, get distinct sectors from existing groups/users
        const groupSectors = await Group.distinct("sector");
        const userSectors = await User.distinct("sector");
        const allSectors = [...new Set([...groupSectors, ...userSectors])].filter(Boolean);
        res.status(200).json({ success: true, data: allSectors });
    } catch (error) {
        next(error);
    }
};

// @desc    Get list of countries (Lookup)
// @route   GET /api/lookup/countries
// @access  Public
exports.getCountries = async (req, res, next) => {
    try {
        // Get distinct countries from existing groups/users
        const groupCountries = await Group.distinct("country");
        const userCountries = await User.distinct("country");
        const allCountries = [...new Set([...groupCountries, ...userCountries])].filter(Boolean);
        res.status(200).json({ success: true, data: allCountries });
    } catch (error) {
        next(error);
    }
};
