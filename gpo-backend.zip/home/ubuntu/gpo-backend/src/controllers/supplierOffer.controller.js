const SupplierOffer = require('../models/SupplierOffer');
const Group = require('../models/Group');
const User = require('../models/User');

// @desc    Get all open RQFs
// @route   GET /api/supplier-offers/open-rqfs
// @access  Public
exports.getOpenRQFs = async (req, res, next) => {
  try {
    // Find groups with RQF open
    const groups = await Group.find({
      status: { $in: ['approved', 'active'] },
      // This is a simplified approach - in a real app, you might have a specific field for RQF status
      resourceType: { $in: ['product', 'service', 'material'] }
    }).populate('creator', 'username fullName');
    
    res.status(200).json({
      success: true,
      count: groups.length,
      data: groups
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Submit supplier offer
// @route   POST /api/supplier-offers
// @access  Private/Supplier
exports.submitOffer = async (req, res, next) => {
  try {
    const { 
      group, 
      companyName, 
      price, 
      currency, 
      quantity, 
      unit, 
      deliveryTime, 
      description, 
      attachments 
    } = req.body;
    
    // Check if group exists
    const groupExists = await Group.findById(group);
    
    if (!groupExists) {
      return res.status(404).json({
        success: false,
        message: 'Group not found'
      });
    }
    
    // Check if group is accepting offers
    if (!['approved', 'active'].includes(groupExists.status)) {
      return res.status(400).json({
        success: false,
        message: 'This group is not accepting offers at this time'
      });
    }
    
    // Create offer
    const offer = await SupplierOffer.create({
      group,
      supplier: req.user.id,
      companyName,
      price,
      currency: currency || 'USD',
      quantity,
      unit,
      deliveryTime,
      description,
      attachments: attachments || [],
      status: 'pending'
    });
    
    // Add offer to group's supplierOffers
    await Group.findByIdAndUpdate(group, {
      $push: { supplierOffers: offer._id }
    });
    
    res.status(201).json({
      success: true,
      data: offer
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get offer details
// @route   GET /api/supplier-offers/:id
// @access  Private
exports.getOfferById = async (req, res, next) => {
  try {
    const offer = await SupplierOffer.findById(req.params.id)
      .populate('group', 'name description')
      .populate('supplier', 'username fullName company');
    
    if (!offer) {
      return res.status(404).json({
        success: false,
        message: 'Offer not found'
      });
    }
    
    // Check if user has access to this offer
    const isSupplier = offer.supplier._id.toString() === req.user.id;
    const isGroupMember = await Group.findOne({
      _id: offer.group._id,
      'members.user': req.user.id
    });
    const isAdmin = ['admin', 'supervisor'].includes(req.user.role);
    
    if (!isSupplier && !isGroupMember && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this offer'
      });
    }
    
    res.status(200).json({
      success: true,
      data: offer
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all supplier offers for a group
// @route   GET /api/groups/:id/supplier-offers
// @access  Private
exports.getGroupOffers = async (req, res, next) => {
  try {
    const group = await Group.findById(req.params.id);
    
    if (!group) {
      return res.status(404).json({
        success: false,
        message: 'Group not found'
      });
    }
    
    // Check if user has access to this group
    const isMember = group.members.some(member => member.user.toString() === req.user.id);
    const isAdmin = ['admin', 'supervisor'].includes(req.user.role);
    
    if (!isMember && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this group\'s offers'
      });
    }
    
    const offers = await SupplierOffer.find({ group: req.params.id })
      .populate('supplier', 'username fullName company');
    
    res.status(200).json({
      success: true,
      count: offers.length,
      data: offers
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Review supplier offer
// @route   PUT /api/supplier-offers/:id/review
// @access  Private/Admin
exports.reviewOffer = async (req, res, next) => {
  try {
    const { status } = req.body;
    
    if (!status || !['approved', 'rejected'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid status (approved or rejected)'
      });
    }
    
    let offer = await SupplierOffer.findById(req.params.id);
    
    if (!offer) {
      return res.status(404).json({
        success: false,
        message: 'Offer not found'
      });
    }
    
    // Update offer status
    offer = await SupplierOffer.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: offer
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all offers submitted by current supplier
// @route   GET /api/supplier-offers/my
// @access  Private/Supplier
exports.getMyOffers = async (req, res, next) => {
  try {
    const offers = await SupplierOffer.find({ supplier: req.user.id })
      .populate('group', 'name description status');
    
    res.status(200).json({
      success: true,
      count: offers.length,
      data: offers
    });
  } catch (error) {
    next(error);
  }
};
