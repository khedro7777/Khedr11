const User = require('../models/User');

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id)
      .select('-password')
      .populate('createdGroups')
      .populate('joinedGroups');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
exports.updateUserProfile = async (req, res, next) => {
  try {
    const { username, email, fullName, country, sector, company, profileImage } = req.body;
    
    // Check if email or username already exists
    if (email || username) {
      const existingUser = await User.findOne({
        $and: [
          { _id: { $ne: req.user.id } },
          { $or: [
            { email: email || '' },
            { username: username || '' }
          ]}
        ]
      });
      
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'Email or username already taken'
        });
      }
    }
    
    // Update user
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      {
        username: username || req.user.username,
        email: email || req.user.email,
        fullName: fullName || req.user.fullName,
        country: country || req.user.country,
        sector: sector || req.user.sector,
        company: company || req.user.company,
        profileImage: profileImage || req.user.profileImage
      },
      { new: true, runValidators: true }
    ).select('-password');
    
    res.status(200).json({
      success: true,
      data: updatedUser
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user by ID
// @route   GET /api/users/:id
// @access  Private/Admin
exports.getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password')
      .populate('createdGroups')
      .populate('joinedGroups');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all users
// @route   GET /api/users
// @access  Private/Admin
exports.getUsers = async (req, res, next) => {
  try {
    const { role, country, sector } = req.query;
    const filter = {};
    
    if (role) filter.role = role;
    if (country) filter.country = country;
    if (sector) filter.sector = sector;
    
    const users = await User.find(filter).select('-password');
    
    res.status(200).json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    next(error);
  }
};
