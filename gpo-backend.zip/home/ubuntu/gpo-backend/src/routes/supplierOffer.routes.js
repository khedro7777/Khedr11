const express = require('express');
const { 
  getOpenRQFs, 
  submitOffer, 
  getOfferById, 
  getGroupOffers, 
  reviewOffer, 
  getMyOffers 
} = require('../controllers/supplierOffer.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

const router = express.Router();

// Supplier offer routes
router.get('/open-rqfs', getOpenRQFs);
router.post('/', protect, authorize('supplier'), submitOffer);
router.get('/:id', protect, getOfferById);
router.get('/group/:id', protect, getGroupOffers);
router.put('/:id/review', protect, authorize('admin', 'supervisor'), reviewOffer);
router.get('/my', protect, authorize('supplier'), getMyOffers);

module.exports = router;
