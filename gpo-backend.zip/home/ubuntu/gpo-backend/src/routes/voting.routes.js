const express = require("express");
const {
  createVote,
  getVoteById,
  getGroupVotes,
  submitVote,
  getVoteResults,
  updateVoteStatus
} = require("../controllers/voting.controller");
const { protect, authorize } = require("../middleware/auth.middleware");

const router = express.Router();

// Middleware to check group membership for specific routes
const checkGroupMembership = async (req, res, next) => {
    try {
        const voteId = req.params.id;
        const vote = await require('../models/Voting').findById(voteId).populate('group', 'members');
        if (!vote) {
            return res.status(404).json({ success: false, message: "Vote not found" });
        }
        const isMember = vote.group.members.some(member => member.user.toString() === req.user.id);
        const isAdmin = ["admin", "supervisor"].includes(req.user.role);
        if (!isMember && !isAdmin) {
            return res.status(403).json({ success: false, message: "Not authorized for this action in this group" });
        }
        req.vote = vote; // Pass vote object to next middleware/controller
        next();
    } catch (error) {
        next(error);
    }
};

// Voting routes
router.post("/", protect, createVote); // Creator/Group Admin
router.get("/:id", protect, checkGroupMembership, getVoteById); // Group Member/Admin
router.post("/:id/vote", protect, checkGroupMembership, submitVote); // Group Member
router.get("/:id/results", protect, checkGroupMembership, getVoteResults); // Group Member/Admin (after end)
router.put("/:id/status", protect, updateVoteStatus); // Creator/Group Admin/System Admin

// Route to get votes for a specific group (already exists in group.routes.js conceptually, but good to have here too)
// This route is better placed under groups: GET /api/groups/:groupId/voting
// Adding it here for completeness based on controller, but might be redundant
router.get("/group/:groupId", protect, getGroupVotes); // Group Member/Admin

module.exports = router;
