const express = require("express");
const {
  searchGroups,
  searchUsers,
  getSectors,
  getCountries
} = require("../controllers/search.controller");
const { protect, authorize } = require("../middleware/auth.middleware");

const router = express.Router();

// Search routes
router.get("/groups", searchGroups); // Public access (filtered internally)
router.get("/users", protect, authorize("admin", "supervisor"), searchUsers); // Admin only

// Lookup routes (can be nested under /search or have their own /lookup route)
router.get("/lookup/sectors", getSectors); // Public
router.get("/lookup/countries", getCountries); // Public

module.exports = router;
