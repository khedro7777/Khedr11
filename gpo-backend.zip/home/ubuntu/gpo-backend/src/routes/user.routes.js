const express = require('express');
const { getUserProfile, updateUserProfile, getUserById, getUsers } = require('../controllers/user.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

const router = express.Router();

// User routes
router.get('/profile', protect, getUserProfile);
router.put('/profile', protect, updateUserProfile);
router.get('/:id', protect, authorize('admin', 'supervisor'), getUserById);
router.get('/', protect, authorize('admin', 'supervisor'), getUsers);

module.exports = router;
